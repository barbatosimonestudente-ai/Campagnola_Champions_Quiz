﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

// =====================================
// MODELLI DI COMUNICAZIONE
// =====================================

public class Message
{
    public string Type { get; set; } = "";
    public string Name { get; set; } = "";
    public string Text { get; set; } = "";

    public int QuestionNumber { get; set; }
    public int TotalQuestions { get; set; }

    public string Category { get; set; } = "";
    public string Question { get; set; } = "";

    public List<string>? Answers { get; set; }

    public int AnswerIndex { get; set; }
    public int CorrectAnswer { get; set; }

    public bool Correct { get; set; }
    public int Points { get; set; }

    public List<ScoreInfo>? Scores { get; set; }
}

public class ScoreInfo
{
    public string Name { get; set; } = "";
    public int Score { get; set; }
}

// =====================================
// CLIENT
// =====================================

class Program
{
    const int PORT = 5000;

    static async Task Main(string[] args)
    {
        Console.WriteLine("================================");
        Console.WriteLine("         CLIENT QUIZ");
        Console.WriteLine("================================");

        // Indirizzo del server

        Console.Write("Inserisci IP del server: ");

        string? ip = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(ip))
            ip = "127.0.0.1";

        // Nome giocatore

        Console.Write("Inserisci il tuo nome: ");

        string? playerName = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(playerName))
        {
            Console.WriteLine("Nome non valido.");
            return;
        }

        // Connessione TCP

        using TcpClient client = new TcpClient();

        try
        {
            await client.ConnectAsync(ip, PORT);

            Console.WriteLine();
            Console.WriteLine("Connessione al server effettuata!");
        }
        catch
        {
            Console.WriteLine("Impossibile collegarsi al server.");
            return;
        }

        NetworkStream stream = client.GetStream();

        using StreamReader reader =
            new StreamReader(stream, Encoding.UTF8);

        using StreamWriter writer =
            new StreamWriter(stream, Encoding.UTF8)
            {
                AutoFlush = true
            };

        // =====================================
        // INVIO NOME AL SERVER
        // =====================================

        Message joinMessage = new Message
        {
            Type = "join",
            Name = playerName
        };

        await SendAsync(writer, joinMessage);

        Console.WriteLine();
        Console.WriteLine("In attesa dell'inizio della partita...");

        // =====================================
        // RICEZIONE MESSAGGI DAL SERVER
        // =====================================

        while (true)
        {
            string? data = await reader.ReadLineAsync();

            if (data == null)
            {
                Console.WriteLine("Connessione terminata.");
                break;
            }

            Message? message =
                JsonSerializer.Deserialize<Message>(data);

            if (message == null)
                continue;

            switch (message.Type)
            {
                // ---------------------------------
                // CONNESSIONE CONFERMATA
                // ---------------------------------

                case "welcome":

                    Console.WriteLine(message.Text);

                    break;

                // ---------------------------------
                // ERRORE
                // ---------------------------------

                case "error":

                    Console.WriteLine(message.Text);

                    return;

                // ---------------------------------
                // NUOVA DOMANDA
                // ---------------------------------

                case "question":

                    Console.WriteLine();
                    Console.WriteLine("================================");
                    Console.WriteLine(
                        $"DOMANDA {message.QuestionNumber}" +
                        $"/{message.TotalQuestions}");

                    Console.WriteLine(
                        $"Categoria: {message.Category}");

                    Console.WriteLine("================================");

                    Console.WriteLine();
                    Console.WriteLine(message.Question);

                    Console.WriteLine();

                    // Visualizzazione risposte

                    if (message.Answers == null)
                        break;

                    for (int i = 0; i < message.Answers.Count; i++)
                    {
                        Console.WriteLine(
                            $"{i + 1}) {message.Answers[i]}");
                    }

                    Console.WriteLine();

                    int answer;

                    // Controllo input

                    while (true)
                    {
                        Console.Write(
                            "Inserisci la tua risposta (1-4): ");

                        string? input = Console.ReadLine();

                        if (int.TryParse(input, out answer) &&
                            answer >= 1 &&
                            answer <= message.Answers.Count)
                        {
                            break;
                        }

                        Console.WriteLine(
                            "Risposta non valida. Riprova.");
                    }

                    // Invio risposta al server
                    // Conversione da 1-4 a 0-3

                    Message answerMessage = new Message
                    {
                        Type = "answer",
                        AnswerIndex = answer - 1
                    };

                    await SendAsync(writer, answerMessage);

                    Console.WriteLine();
                    Console.WriteLine(
                        "Risposta inviata! Attendi gli altri giocatori...");

                    break;

                // ---------------------------------
                // RISULTATO RISPOSTA
                // ---------------------------------

                case "result":

                    Console.WriteLine();

                    if (message.Correct)
                    {
                        Console.ForegroundColor =
                            ConsoleColor.Green;

                        Console.WriteLine("RISPOSTA CORRETTA!");

                        Console.ResetColor();
                    }
                    else
                    {
                        Console.ForegroundColor =
                            ConsoleColor.Red;

                        Console.WriteLine("RISPOSTA SBAGLIATA!");

                        Console.ResetColor();
                    }

                    Console.WriteLine(
                        $"Punti ottenuti: +{message.Points}");

                    if (message.CorrectAnswer >= 0)
                    {
                        // L'indice della risposta corretta
                        // è comunicato dal server.
                        Console.WriteLine(
                            $"Risposta corretta: " +
                            $"{message.CorrectAnswer + 1}");
                    }

                    Console.WriteLine();
                    Console.WriteLine(
                        "Attendi la prossima domanda...");

                    break;

                // ---------------------------------
                // CLASSIFICA FINALE
                // ---------------------------------

                case "final":

                    Console.WriteLine();
                    Console.WriteLine("================================");
                    Console.WriteLine("       CLASSIFICA FINALE");
                    Console.WriteLine("================================");

                    if (message.Scores != null)
                    {
                        int position = 1;

                        foreach (ScoreInfo score in message.Scores)
                        {
                            Console.WriteLine(
                                $"{position}° posto - " +
                                $"{score.Name}: {score.Score} punti");

                            position++;
                        }
                    }

                    Console.WriteLine();
                    Console.WriteLine("PARTITA TERMINATA!");

                    return;
            }
        }
    }

    // =====================================
    // INVIO MESSAGGI
    // =====================================

    static async Task SendAsync(
        StreamWriter writer,
        Message message)
    {
        string json = JsonSerializer.Serialize(message);

        await writer.WriteLineAsync(json);
    }
}
