﻿
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

// =====================================
// MODELLI
// =====================================

public class QuizData
{
    [JsonPropertyName("title")]
    public string Title { get; set; } = "";

    [JsonPropertyName("total_questions")]
    public int TotalQuestions { get; set; }

    [JsonPropertyName("questions")]
    public List<QuizQuestion> Questions { get; set; } = new();
}

public class QuizQuestion
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("category")]
    public string Category { get; set; } = "";

    [JsonPropertyName("question")]
    public string Question { get; set; } = "";

    [JsonPropertyName("answers")]
    public List<string> Answers { get; set; } = new();

    [JsonPropertyName("correct_answer")]
    public int CorrectAnswer { get; set; }
}

// Messaggio utilizzato per comunicare
// tra server e client.

public class Message
{
    public string Type { get; set; } = "";
    public string Name { get; set; } = "";
    public string Text { get; set; } = "";

    public int QuestionNumber { get; set; }
    public int TotalQuestions { get; set; }

    public string Category { get; set; } = "";
    public string Question { get; set; } = "";

    public List<string>? Answers { get; set; }

    public int AnswerIndex { get; set; }
    public int CorrectAnswer { get; set; }

    public bool Correct { get; set; }
    public int Points { get; set; }

    public List<ScoreInfo>? Scores { get; set; }
}

public class ScoreInfo
{
    public string Name { get; set; } = "";
    public int Score { get; set; }
}

// =====================================
// GIOCATORE
// =====================================

public class Player
{
    public Guid Id { get; } = Guid.NewGuid();

    public string Name { get; set; } = "";

    public int Score { get; set; } = 0;

    public TcpClient Client { get; }

    public StreamReader Reader { get; }

    public StreamWriter Writer { get; }

    public Player(TcpClient client)
    {
        Client = client;

        NetworkStream stream = client.GetStream();

        Reader = new StreamReader(
            stream, Encoding.UTF8);

        Writer = new StreamWriter(
            stream, Encoding.UTF8)
        {
            AutoFlush = true
        };
    }
}

// =====================================
// SERVER
// =====================================

class Program
{
    const int PORT = 5000;
    const int POINTS_PER_CORRECT_ANSWER = 10;

    static ConcurrentDictionary<Guid, Player> players = new();

    static volatile bool gameStarted = false;

    static readonly JsonSerializerOptions jsonOptions =
        new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

    static async Task Main(string[] args)
    {
        Console.WriteLine("================================");
        Console.WriteLine("       SERVER QUIZ");
        Console.WriteLine("================================");

        // Caricamento JSON

        string jsonPath = Path.Combine(
            AppContext.BaseDirectory,
            "Domande.json");

        if (!File.Exists(jsonPath))
        {
            Console.WriteLine("File domande.json non trovato!");
            return;
        }

        string json = await File.ReadAllTextAsync(jsonPath);

        QuizData? quiz = JsonSerializer.Deserialize<QuizData>(
            json, jsonOptions);

        if (quiz == null || quiz.Questions.Count == 0)
        {
            Console.WriteLine("Errore nel caricamento delle domande.");
            return;
        }

        Console.WriteLine(
            $"Quiz caricato: {quiz.Title}");

        Console.WriteLine(
            $"Domande disponibili: {quiz.Questions.Count}");

        // Avvio listener TCP

        TcpListener listener = new TcpListener(
            IPAddress.Any, PORT);

        listener.Start();

        Console.WriteLine();
        Console.WriteLine($"Server in ascolto sulla porta {PORT}");
        Console.WriteLine("In attesa dei giocatori...");
        Console.WriteLine();

        // Accettazione continua dei client

        _ = AcceptClientsAsync(listener);

        Console.WriteLine("Scrivi START per iniziare la partita.");
        Console.WriteLine("Attendi che tutti i giocatori si colleghino.");

        string? command;

        do
        {
            command = Console.ReadLine();

        } while (command?.Trim().ToUpper() != "START"
                 || players.IsEmpty);

        // Impedisce nuovi ingressi durante la partita

        gameStarted = true;

        Console.WriteLine();
        Console.WriteLine("================================");
        Console.WriteLine("       PARTITA INIZIATA!");
        Console.WriteLine("================================");

        Console.WriteLine(
            $"Giocatori: {players.Count}");

        // Avvio quiz

        await StartQuizAsync(quiz);

        listener.Stop();

        Console.WriteLine();
        Console.WriteLine("Partita terminata.");
    }

    // =====================================
    // ACCETTAZIONE CLIENT
    // =====================================

    static async Task AcceptClientsAsync(TcpListener listener)
    {
        while (true)
        {
            TcpClient client;

            try
            {
                client = await listener.AcceptTcpClientAsync();
            }
            catch
            {
                break;
            }

            _ = Task.Run(() => HandleClientAsync(client));
        }
    }

    // =====================================
    // REGISTRAZIONE GIOCATORE
    // =====================================

    static async Task HandleClientAsync(TcpClient client)
    {
        Player player;

        try
        {
            player = new Player(client);

            string? data = await player.Reader.ReadLineAsync();

            if (data == null)
            {
                client.Close();
                return;
            }

            Message? message =
                JsonSerializer.Deserialize<Message>(
                    data, jsonOptions);

            if (message == null ||
                message.Type != "join" ||
                string.IsNullOrWhiteSpace(message.Name))
            {
                client.Close();
                return;
            }

            if (gameStarted)
            {
                await SendAsync(player, new Message
                {
                    Type = "error",
                    Text = "La partita è già iniziata."
                });

                client.Close();
                return;
            }

            player.Name = message.Name.Trim();

            players[player.Id] = player;

            Console.WriteLine(
                $"Giocatore collegato: {player.Name}");

            await SendAsync(player, new Message
            {
                Type = "welcome",
                Text = "Connessione effettuata! Attendi l'inizio della partita."
            });
        }
        catch
        {
            client.Close();
        }
    }

    // =====================================
    // INVIO MESSAGGI
    // =====================================

    static async Task SendAsync(Player player, Message message)
    {
        string json = JsonSerializer.Serialize(message);

        await player.Writer.WriteLineAsync(json);
    }

    // =====================================
    // GESTIONE PARTITA
    // =====================================

    static async Task StartQuizAsync(QuizData quiz)
    {
        List<Player> gamePlayers = players.Values.ToList();

        foreach (QuizQuestion question in quiz.Questions)
        {
            Console.WriteLine();
            Console.WriteLine("--------------------------------");
            Console.WriteLine(
                $"DOMANDA {question.Id}/{quiz.Questions.Count}");

            Console.WriteLine(question.Question);

            // Invio della stessa domanda a tutti

            foreach (Player player in gamePlayers)
            {
                try
                {
                    await SendAsync(player, new Message
                    {
                        Type = "question",
                        QuestionNumber = question.Id,
                        TotalQuestions = quiz.Questions.Count,
                        Category = question.Category,
                        Question = question.Question,
                        Answers = question.Answers
                    });
                }
                catch
                {
                    players.TryRemove(player.Id, out _);
                }
            }

            // Ricezione simultanea delle risposte

            var tasks = gamePlayers.Select(
                player => ReceiveAnswerAsync(player)
            );

            var results = await Task.WhenAll(tasks);

            // Calcolo punteggi

            for (int i = 0; i < gamePlayers.Count; i++)
            {
                Player player = gamePlayers[i];

                int? answer = results[i];

                if (answer == null)
                    continue;

                bool correct =
                    answer.Value == question.CorrectAnswer;

                int points = correct
                    ? POINTS_PER_CORRECT_ANSWER
                    : 0;

                player.Score += points;

                Console.WriteLine(
                    $"{player.Name}: " +
                    $"{(correct ? "CORRETTA" : "ERRATA")} " +
                    $"(+{points} punti) - Totale: {player.Score}");

                // Comunicazione risultato al client

                try
                {
                    await SendAsync(player, new Message
                    {
                        Type = "result",
                        Correct = correct,
                        CorrectAnswer = question.CorrectAnswer,
                        AnswerIndex = answer.Value,
                        Points = points,
                        Text = correct
                            ? "Risposta corretta!"
                            : "Risposta sbagliata!"
                    });
                }
                catch
                {
                    players.TryRemove(player.Id, out _);
                }
            }

            // Rimuove giocatori disconnessi

            gamePlayers = gamePlayers
                .Where(p => players.ContainsKey(p.Id))
                .ToList();
        }

        // =====================================
        // CLASSIFICA FINALE
        // =====================================

        List<ScoreInfo> ranking = gamePlayers
            .OrderByDescending(p => p.Score)
            .Select(p => new ScoreInfo
            {
                Name = p.Name,
                Score = p.Score
            })
            .ToList();

        Console.WriteLine();
        Console.WriteLine("================================");
        Console.WriteLine("       CLASSIFICA FINALE");
        Console.WriteLine("================================");

        for (int i = 0; i < ranking.Count; i++)
        {
            Console.WriteLine(
                $"{i + 1}° posto: {ranking[i].Name} " +
                "- " + ranking[i].Score + " punti");
        }

        // Invio classifica a tutti i client

        foreach (Player player in gamePlayers)
        {
            try
            {
                await SendAsync(player, new Message
                {
                    Type = "final",
                    Scores = ranking
                });

                player.Client.Close();
            }
            catch
            {
                player.Client.Close();
            }
        }
    }

    // =====================================
    // RICEZIONE RISPOSTA CLIENT
    // =====================================

    static async Task<int?> ReceiveAnswerAsync(Player player)
    {
        try
        {
            string? data = await player.Reader.ReadLineAsync();

            if (data == null)
            {
                players.TryRemove(player.Id, out _);
                player.Client.Close();
                return null;
            }

            Message? message =
                JsonSerializer.Deserialize<Message>(
                    data, jsonOptions);

            if (message == null ||
                message.Type != "answer" ||
                message.AnswerIndex < 0 ||
                message.AnswerIndex > 3)
            {
                return null;
            }

            return message.AnswerIndex;
        }
        catch
        {
            players.TryRemove(player.Id, out _);
            player.Client.Close();
            return null;
        }
    }
}
