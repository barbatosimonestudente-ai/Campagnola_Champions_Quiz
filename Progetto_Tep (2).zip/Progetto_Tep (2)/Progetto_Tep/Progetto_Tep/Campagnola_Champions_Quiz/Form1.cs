namespace Campagnola_Champions_Quiz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Inserisci il nome utente!");
                return;
            }
            Form2 f2 = new Form2();
            f2.Show();
            f2.Show();
            this.Hide();
        }
    }
}
