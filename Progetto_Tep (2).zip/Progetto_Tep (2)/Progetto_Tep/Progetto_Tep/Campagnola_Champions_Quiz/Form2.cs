﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace Campagnola_Champions_Quiz
{
    public partial class Form2 : Form
    {
        private CheckBox[] tutte;
        private List<Domanda> domande;
        private List<Domanda> rimanenti;
        private Domanda corrente;
        private readonly Random rnd = new Random();
        private readonly CancellationTokenSource cts = new CancellationTokenSource();

        private Label lblPunteggio;
        private Label lblEsito;
        private int punteggio = 0;
        private bool risposto = false;
        private bool aggiornando = false;

        // Se nel JSON correct_answer parte da 1 (1..4) invece che da 0, metti true
        private const bool RispostaPartiDa1 = false;

        private const int SecondiPerRispondere = 10;
        private const int MillisecondiSoluzione = 3000;

        private int IndiceCorretto => RispostaPartiDa1 ? corrente.correct_answer - 1 : corrente.correct_answer;

        public Form2()
        {
            InitializeComponent();
            tutte = new[] { checkBox1, checkBox2, checkBox3, checkBox4 };

            foreach (var cb in tutte)
                cb.CheckedChanged += checkBox_CheckedChanged;

            lblPunteggio = new Label
            {
                AutoSize = true,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Text = "Punteggio: 0",
                Location = new Point(12, ClientSize.Height - 35),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left
            };
            Controls.Add(lblPunteggio);
            lblPunteggio.BringToFront();

            lblEsito = new Label
            {
                AutoSize = true,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Text = "",
                Location = new Point(200, ClientSize.Height - 35),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left
            };
            Controls.Add(lblEsito);
            lblEsito.BringToFront();

            FormClosing += (s, e) => cts.Cancel();
        }

        private async void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                string percorso = Path.Combine(Application.StartupPath, "quiz.json");
                string json = File.ReadAllText(percorso);

                var dati = JsonSerializer.Deserialize<QuizData>(json);
                domande = dati.questions;
                rimanenti = new List<Domanda>(domande);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore nel caricamento del file quiz.json:\n" + ex.Message);
                return;
            }

            await CicloDomande();
        }

        private async Task CicloDomande()
        {
            try
            {
                while (!cts.IsCancellationRequested)
                {
                    MostraNuovaDomanda();

                    // Attende la risposta (max 10 secondi), controllando ogni 100 ms
                    int attesa = 0;
                    while (!risposto && attesa < SecondiPerRispondere * 1000)
                    {
                        await Task.Delay(100, cts.Token);
                        attesa += 100;
                    }

                    // Tempo scaduto senza risposta
                    if (!risposto)
                    {
                        risposto = true;
                        lblEsito.ForeColor = Color.DarkOrange;
                        lblEsito.Text = "Tempo scaduto!";
                        RivelaRisposta(-1);
                    }

                    // Tempo per leggere la soluzione
                    await Task.Delay(MillisecondiSoluzione, cts.Token);
                }
            }
            catch (OperationCanceledException)
            {
                // form chiusa
            }
        }

        private void MostraNuovaDomanda()
        {
            if (rimanenti.Count == 0)
                rimanenti = new List<Domanda>(domande);

            int indice = rnd.Next(rimanenti.Count);
            corrente = rimanenti[indice];
            rimanenti.RemoveAt(indice);

            risposto = false;
            label1.Text = corrente.question;
            lblEsito.Text = "";

            aggiornando = true;
            for (int i = 0; i < tutte.Length; i++)
            {
                var cb = tutte[i];
                cb.Checked = false;
                cb.Enabled = true;
                cb.BackColor = SystemColors.Control;
                cb.Text = corrente.answers[i];
            }
            aggiornando = false;
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (aggiornando) return;

            var scelta = (CheckBox)sender;

            // Domanda già chiusa: annulla la modifica
            if (risposto)
            {
                aggiornando = true;
                scelta.Checked = !scelta.Checked;
                aggiornando = false;
                return;
            }

            if (!scelta.Checked) return;

            risposto = true;
            int indiceScelto = Array.IndexOf(tutte, scelta);

            if (indiceScelto == IndiceCorretto)
            {
                punteggio += 10;
                lblPunteggio.Text = "Punteggio: " + punteggio;
                lblEsito.ForeColor = Color.Green;
                lblEsito.Text = "Giusto! +10 punti";
            }
            else
            {
                lblEsito.ForeColor = Color.Red;
                lblEsito.Text = "Sbagliato!";
            }

            RivelaRisposta(indiceScelto);
        }

        // indiceScelto = -1 se l'utente non ha risposto
        private void RivelaRisposta(int indiceScelto)
        {
            for (int i = 0; i < tutte.Length; i++)
            {
                if (i == IndiceCorretto)
                {
                    tutte[i].BackColor = Color.LightGreen;
                    tutte[i].Text = corrente.answers[i] + "  ✓";
                }
                else if (i == indiceScelto)
                {
                    tutte[i].BackColor = Color.LightCoral;
                    tutte[i].Text = corrente.answers[i] + "  ✗";
                }
            }
        }
    }

    public class Domanda
    {
        public int id { get; set; }
        public string category { get; set; }
        public string question { get; set; }
        public List<string> answers { get; set; }
        public int correct_answer { get; set; }
    }

    public class QuizData
    {
        public string title { get; set; }
        public int total_questions { get; set; }
        public List<Domanda> questions { get; set; }
    }
}