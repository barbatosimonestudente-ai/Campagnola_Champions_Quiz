﻿namespace Campagnola_Champions_Quiz
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.Red;
            checkBox1.Font = new Font("Microsoft Sans Serif", 8.25F);
            checkBox1.Location = new Point(144, 191);
            checkBox1.Name = "checkBox1";
            checkBox1.Padding = new Padding(30);
            checkBox1.Size = new Size(149, 77);
            checkBox1.TabIndex = 2;
            checkBox1.Text = "RISPOSTA 1";
            checkBox1.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = SystemColors.HotTrack;
            checkBox2.Font = new Font("Microsoft Sans Serif", 8.25F);
            checkBox2.Location = new Point(464, 191);
            checkBox2.Name = "checkBox2";
            checkBox2.Padding = new Padding(30);
            checkBox2.Size = new Size(149, 77);
            checkBox2.TabIndex = 3;
            checkBox2.Text = "RISPOSTA 2";
            checkBox2.UseVisualStyleBackColor = false;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.BackColor = Color.Yellow;
            checkBox3.Font = new Font("Microsoft Sans Serif", 8.25F);
            checkBox3.Location = new Point(144, 314);
            checkBox3.Name = "checkBox3";
            checkBox3.Padding = new Padding(30);
            checkBox3.Size = new Size(149, 77);
            checkBox3.TabIndex = 4;
            checkBox3.Text = "RISPOSTA 3";
            checkBox3.UseVisualStyleBackColor = false;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.BackColor = Color.Green;
            checkBox4.Font = new Font("Microsoft Sans Serif", 8.25F);
            checkBox4.Location = new Point(464, 314);
            checkBox4.Name = "checkBox4";
            checkBox4.Padding = new Padding(30);
            checkBox4.Size = new Size(149, 77);
            checkBox4.TabIndex = 5;
            checkBox4.Text = "RISPOSTA 4";
            checkBox4.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(340, 61);
            label1.Name = "label1";
            label1.Size = new Size(68, 15);
            label1.TabIndex = 6;
            label1.Text = "DOMANDA";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(checkBox4);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private Label label1;
    }
}