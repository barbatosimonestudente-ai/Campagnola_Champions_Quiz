﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace Campagnola_Champions_Quiz
{
    public partial class Form2 : Form
    {
        private CheckBox[] tutte;
        private List<Domanda> domande;
        private List<Domanda> rimanenti;   // domande non ancora uscite
        private Domanda corrente;
        private readonly Random rnd = new Random();
        private readonly CancellationTokenSource cts = new CancellationTokenSource();

        public Form2()
        {
            InitializeComponent();
            tutte = new[] { checkBox1, checkBox2, checkBox3, checkBox4 };

            foreach (var cb in tutte)
                cb.CheckedChanged += checkBox_CheckedChanged;

            // Ferma il ciclo quando si chiude la form
            FormClosing += (s, e) => cts.Cancel();
        }

        private async void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                // quiz.json deve stare accanto all'eseguibile (bin\Debug\...)
                string percorso = Path.Combine(Application.StartupPath, "quiz.json");
                string json = File.ReadAllText(percorso);

                var dati = JsonSerializer.Deserialize<QuizData>(json);
                domande = dati.questions;
                rimanenti = new List<Domanda>(domande);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Errore nel caricamento del file quiz.json:\n" + ex.Message);
                return;
            }

            await CicloDomande();
        }

        private async Task CicloDomande()
        {
            try
            {
                while (!cts.IsCancellationRequested)
                {
                    MostraNuovaDomanda();
                    await Task.Delay(10000, cts.Token); // 10 secondi, poi nuova domanda
                }
            }
            catch (TaskCanceledException)
            {
                // form chiusa: esce dal ciclo
            }
        }

        private void MostraNuovaDomanda()
        {
            // Quando finiscono, si ricomincia con tutte
            if (rimanenti.Count == 0)
                rimanenti = new List<Domanda>(domande);

            int indice = rnd.Next(rimanenti.Count);
            corrente = rimanenti[indice];
            rimanenti.RemoveAt(indice);

            label1.Text = corrente.question;

            for (int i = 0; i < tutte.Length; i++)
            {
                var cb = tutte[i];

                cb.CheckedChanged -= checkBox_CheckedChanged; // evita eventi mentre resetto
                cb.Checked = false;
                cb.Enabled = true;
                cb.Text = corrente.answers[i];
                cb.CheckedChanged += checkBox_CheckedChanged;
            }
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            var scelta = (CheckBox)sender;

            if (!scelta.Checked) return;

            // Blocca tutte le checkbox, compresa quella scelta
            foreach (var cb in tutte)
            {
                cb.CheckedChanged -= checkBox_CheckedChanged;
                cb.Enabled = false;
            }
        }
    }

    public class Domanda
    {
        public int id { get; set; }
        public string category { get; set; }
        public string question { get; set; }
        public List<string> answers { get; set; }
        public int correct_answer { get; set; }
    }

    public class QuizData
    {
        public string title { get; set; }
        public int total_questions { get; set; }
        public List<Domanda> questions { get; set; }
    }
}