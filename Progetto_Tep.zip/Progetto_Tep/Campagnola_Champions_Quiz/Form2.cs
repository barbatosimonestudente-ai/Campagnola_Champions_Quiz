﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Campagnola_Champions_Quiz
{
    public partial class Form2 : Form
    {
        private CheckBox[] tutte;

        public Form2()
        {
            InitializeComponent();
            tutte = new[] { checkBox1, checkBox2, checkBox3, checkBox4 };

            foreach (var cb in tutte)
                cb.CheckedChanged += checkBox_CheckedChanged;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            var scelta = (CheckBox)sender;

            if (!scelta.Checked) return;

            // Blocca tutte le checkbox, compresa quella scelta
            foreach (var cb in tutte)
            {
                cb.CheckedChanged -= checkBox_CheckedChanged; // evita richiami a catena
                cb.Enabled = false;
            }

            
        }
    }
}
